# image-logger
a discord image logger that gets user ip, customizable, renders image, renders troll gif when user opens it in browser and is hosted on replit and other websites.

# discord server
incase you need help or something open a ticket in the help-desk channel in my discord server
- https://discord.gg/JtYSjYBtvb

# how to use
1. go in https://replit.com create a account.
2. create a new project and click on the top right corner the button that says "import from github"
3. enter the github repo link https://github.com/zeroo-0/image-logger after doing so press import from github, if doesnt work download the image logger as a zip drag the files and remove .gitignore
4. open stuff folder, then open setting.json and customize your image logger.
5. create a new folder called logs where if save_txt is enabled it will save the ips if all other info.
6. run the replit.
7. send someone the image by adding "/stuff/image.jpg" at the end of the webview link, so it will render the image.
![image](https://user-images.githubusercontent.com/125908067/234425704-b7b5f15d-c4d1-4ceb-bc2a-d0d10fdba17d.png)
8. when the user will open it in browser he will get ip logged and notified on your webhook or his ip saved in the txt file

# FAQ
- FAQ is in my server: https://discord.gg/JtYSjYBtvb

# contributors
- ! zeroo#2801 me
- saiko#2008 helped me developing the ip logger
